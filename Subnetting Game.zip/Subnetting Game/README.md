=== Subnetting game version 0.0.1 ===

Subnetting Game is a simple command-line tool that gives you hands-on practice with subnetting. 
It generates random IPv4 addresses and CIDR values (ranging from /9 to /30) and quizzes you on key subnetting concepts.
I thought of it since i've been looking for some what of a fun tool to practice subnetting but most seemed quite generic, while this one is generic too il be expanding on it later on to make it not.

=== What You'll Practice ===

- Netmask in dotted decimal format

- Magic number

- Subnet IP

- First usable host

- Last usable host

- Broadcast address

=== How It Works ===

The script generates a random IP and CIDR. You're then asked to calculate and input:

The netmask (e.g., 255.255.255.0), The magic number, First and last usable host, broadcast address.
You get instant feedback on your answers and can choose to try again or restart the game.

=== How to run it === 

make sure you have python installed and in a cli and in the subnetting folder directory enter

python SubGAme_Functionalities.py

=== BUILT BY MxLogician ===
